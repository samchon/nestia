import { IJsonSchemaTransformError, ILlmSchema, IResult, OpenApi } from "@typia/interface";
/**
 * OpenAPI to LLM schema converter.
 *
 * `LlmSchemaConverter` converts OpenAPI JSON schemas to LLM-compatible
 * {@link ILlmSchema} format. LLMs don't fully support JSON Schema, so this
 * simplifies schemas by removing unsupported features (tuples, `const`, mixed
 * unions).
 *
 * Main functions:
 *
 * - {@link parameters}: Convert object schema to {@link ILlmSchema.IParameters}
 * - {@link schema}: Convert any schema to {@link ILlmSchema}
 * - {@link invert}: Extract constraints from description back to schema
 *
 * Configuration options ({@link ILlmSchema.IConfig}):
 *
 * - `strict`: OpenAI structured output mode (all properties required)
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace LlmSchemaConverter {
    /**
     * Get configuration with defaults applied.
     *
     * @param config Partial configuration
     * @returns Full configuration with defaults
     */
    const getConfig: (config?: Partial<ILlmSchema.IConfig> | undefined) => ILlmSchema.IConfig;
    /**
     * Convert OpenAPI object schema to LLM parameters schema.
     *
     * @param props.config Conversion configuration
     * @param props.components OpenAPI components for reference resolution
     * @param props.schema Object or reference schema to convert
     * @param props.accessor Error path accessor
     * @param props.refAccessor Reference path accessor
     * @returns Converted parameters or error
     */
    const parameters: (props: {
        config?: Partial<ILlmSchema.IConfig>;
        components: OpenApi.IComponents;
        schema: OpenApi.IJsonSchema.IObject | OpenApi.IJsonSchema.IReference;
        accessor?: string;
        refAccessor?: string;
    }) => IResult<ILlmSchema.IParameters, IJsonSchemaTransformError>;
    /**
     * Convert OpenAPI schema to LLM schema.
     *
     * @param props.config Conversion configuration
     * @param props.components OpenAPI components for reference resolution
     * @param props.$defs Definition store (mutated with referenced types)
     * @param props.schema Schema to convert
     * @param props.accessor Error path accessor
     * @param props.refAccessor Reference path accessor
     * @returns Converted schema or error
     */
    const schema: (props: {
        config?: Partial<ILlmSchema.IConfig>;
        components: OpenApi.IComponents;
        $defs: Record<string, ILlmSchema>;
        schema: OpenApi.IJsonSchema;
        accessor?: string;
        refAccessor?: string;
    }) => IResult<ILlmSchema, IJsonSchemaTransformError>;
    /**
     * Convert LLM schema back to OpenAPI schema.
     *
     * Restores constraint information from description tags and converts `$defs`
     * references to `#/components/schemas`.
     *
     * @param props.components Target components (mutated with definitions)
     * @param props.schema LLM schema to invert
     * @param props.$defs LLM schema definitions
     * @returns OpenAPI JSON schema
     */
    const invert: (props: {
        components: OpenApi.IComponents;
        schema: ILlmSchema;
        $defs: Record<string, ILlmSchema>;
    }) => OpenApi.IJsonSchema;
}
