import { OpenApi, OpenApiV3, OpenApiV3_1, OpenApiV3_2, SwaggerV2 } from "@typia/interface";
/**
 * OpenAPI version converter.
 *
 * `OpenApiConverter` converts between different OpenAPI specification versions:
 * Swagger v2.0, OpenAPI v3.0, OpenAPI v3.1, OpenAPI v3.2, and typia's emended
 * {@link OpenApi} format. Also converts individual components (schemas,
 * operations, paths).
 *
 * Upgrade path (to emended v3.2):
 *
 * - Swagger v2.0 → emended v3.2
 * - OpenAPI v3.0 → emended v3.2
 * - OpenAPI v3.1 → emended v3.2
 * - OpenAPI v3.2 → emended v3.2
 *
 * Downgrade path (from emended v3.2):
 *
 * - Emended v3.2 → Swagger v2.0
 * - Emended v3.2 → OpenAPI v3.0
 * - Emended v3.2 → OpenAPI v3.1
 *
 * The emended format normalizes ambiguous expressions: dereferences `$ref`,
 * merges `allOf`, converts `nullable` to union types, etc.
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace OpenApiConverter {
    /**
     * Upgrade document to typia's emended OpenAPI v3.2 format.
     *
     * @param document Source document (Swagger v2.0, OpenAPI v3.0/v3.1/v3.2)
     * @returns Emended OpenAPI v3.2 document
     */
    function upgradeDocument(document: SwaggerV2.IDocument | OpenApiV3.IDocument | OpenApiV3_1.IDocument | OpenApiV3_2.IDocument | OpenApi.IDocument): OpenApi.IDocument;
    /**
     * Downgrade document to Swagger v2.0 format.
     *
     * @param document Source emended OpenAPI document
     * @param version Target version "2.0"
     * @returns Swagger v2.0 document
     */
    function downgradeDocument(document: OpenApi.IDocument, version: "2.0"): SwaggerV2.IDocument;
    /**
     * Downgrade document to OpenAPI v3.0 format.
     *
     * @param document Source emended OpenAPI document
     * @param version Target version "3.0"
     * @returns OpenAPI v3.0 document
     */
    function downgradeDocument(document: OpenApi.IDocument, version: "3.0"): OpenApiV3.IDocument;
    function downgradeDocument(document: OpenApi.IDocument, version: "3.1"): OpenApiV3_1.IDocument;
    /**
     * Upgrade components to typia's emended format.
     *
     * @param input Source components (Swagger v2.0, OpenAPI v3.0/v3.1/v3.2)
     * @returns Emended OpenAPI components
     */
    function upgradeComponents(input: OpenApiV3_2.IComponents | OpenApiV3_1.IComponents | OpenApiV3.IComponents | SwaggerV2.IDocument): OpenApi.IComponents;
    /**
     * Downgrade components to Swagger v2.0 definitions.
     *
     * @param input Source emended components
     * @param version Target version "2.0"
     * @returns Swagger v2.0 definitions record
     */
    function downgradeComponents(input: OpenApi.IComponents, version: "2.0"): Record<string, SwaggerV2.IJsonSchema>;
    /**
     * Downgrade components to OpenAPI v3.0 format.
     *
     * @param input Source emended components
     * @param version Target version "3.0"
     * @returns OpenAPI v3.0 components
     */
    function downgradeComponents(input: OpenApi.IComponents, version: "3.0"): OpenApiV3.IComponents;
    /**
     * Downgrade components to OpenAPI v3.1 format.
     *
     * @param input Source emended components
     * @param version Target version "3.1"
     * @returns OpenAPI v3.1 components
     */
    function downgradeComponents(input: OpenApi.IComponents, version: "3.1"): OpenApiV3_1.IComponents;
    /**
     * Upgrade Swagger v2.0 schema to emended format.
     *
     * @param props.definitions Swagger v2.0 definitions
     * @param props.schema Schema to upgrade
     * @returns Emended JSON schema
     */
    function upgradeSchema(props: {
        definitions: Record<string, SwaggerV2.IJsonSchema>;
        schema: SwaggerV2.IJsonSchema;
    }): OpenApi.IJsonSchema;
    /**
     * Upgrade OpenAPI v3.0 schema to emended format.
     *
     * @param props.components OpenAPI v3.0 components
     * @param props.schema Schema to upgrade
     * @returns Emended JSON schema
     */
    function upgradeSchema(props: {
        components: OpenApiV3.IComponents;
        schema: OpenApiV3.IJsonSchema;
    }): OpenApi.IJsonSchema;
    /**
     * Upgrade OpenAPI v3.1 schema to emended format.
     *
     * @param props.components OpenAPI v3.1 components
     * @param props.schema Schema to upgrade
     * @returns Emended JSON schema
     */
    function upgradeSchema(props: {
        components: OpenApiV3_1.IComponents;
        schema: OpenApiV3_1.IJsonSchema;
    }): OpenApi.IJsonSchema;
    /**
     * Upgrade OpenAPI v3.2 schema to emended format.
     *
     * @param props.components OpenAPI v3.2 components
     * @param props.schema Schema to upgrade
     * @returns Emended JSON schema
     */
    function upgradeSchema(props: {
        components: OpenApiV3_2.IComponents;
        schema: OpenApiV3_2.IJsonSchema;
    }): OpenApi.IJsonSchema;
    /**
     * Downgrade schema to Swagger v2.0 format.
     *
     * @param props.components Source emended components
     * @param props.schema Schema to downgrade
     * @param props.version Target version "2.0"
     * @param props.downgraded Target definitions record (mutated)
     * @returns Swagger v2.0 schema
     */
    function downgradeSchema(props: {
        components: OpenApi.IComponents;
        schema: OpenApi.IJsonSchema;
        version: "2.0";
        downgraded: Record<string, SwaggerV2.IJsonSchema>;
    }): SwaggerV2.IJsonSchema;
    /**
     * Downgrade schema to OpenAPI v3.0 format.
     *
     * @param props.components Source emended components
     * @param props.schema Schema to downgrade
     * @param props.version Target version "3.0"
     * @param props.downgraded Target components (mutated)
     * @returns OpenAPI v3.0 schema
     */
    function downgradeSchema(props: {
        components: OpenApi.IComponents;
        schema: OpenApi.IJsonSchema;
        version: "3.0";
        downgraded: OpenApiV3.IComponents;
    }): OpenApiV3.IJsonSchema;
    /**
     * Downgrade schema to OpenAPI v3.1 format.
     *
     * @param props.components Source emended components
     * @param props.schema Schema to downgrade
     * @param props.version Target version "3.1"
     * @param props.downgraded Target components (mutated)
     * @returns OpenAPI v3.1 schema
     */
    function downgradeSchema(props: {
        components: OpenApi.IComponents;
        schema: OpenApi.IJsonSchema;
        version: "3.1";
        downgraded: OpenApiV3_1.IComponents;
    }): OpenApiV3_1.IJsonSchema;
}
