import { OpenApi, SwaggerV2 } from "@typia/interface";
export declare namespace SwaggerV2Upgrader {
    const convert: (input: SwaggerV2.IDocument) => OpenApi.IDocument;
    const convertComponents: (input: SwaggerV2.IDocument) => OpenApi.IComponents;
    const convertSchema: (definitions: Record<string, SwaggerV2.IJsonSchema>) => (input: SwaggerV2.IJsonSchema) => OpenApi.IJsonSchema;
}
