import { OpenApi, OpenApiV3_2 } from "@typia/interface";
/**
 * OpenAPI v3.2 to emended OpenApi converter.
 *
 * Reuses JSON Schema conversion logic from OpenApiV3_1Upgrader since the schema
 * format is identical between v3.1 and v3.2.
 */
export declare namespace OpenApiV3_2Upgrader {
    const convert: (input: OpenApiV3_2.IDocument) => OpenApi.IDocument;
    const convertComponents: (input: OpenApiV3_2.IComponents) => OpenApi.IComponents;
    /**
     * Reuse schema conversion from OpenApiV3_1Upgrader. OpenAPI v3.2 uses the
     * same JSON Schema (2020-12) as v3.1.
     */
    const convertSchema: (components: OpenApiV3_2.IComponents) => (input: OpenApiV3_2.IJsonSchema) => OpenApi.IJsonSchema;
}
