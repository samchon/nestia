import { OpenApi, OpenApiV3 } from "@typia/interface";
export declare namespace OpenApiV3Upgrader {
    const convert: (input: OpenApiV3.IDocument) => OpenApi.IDocument;
    const convertComponents: (input: OpenApiV3.IComponents) => OpenApi.IComponents;
    const convertSchema: (components: OpenApiV3.IComponents) => (input: OpenApiV3.IJsonSchema) => OpenApi.IJsonSchema;
}
