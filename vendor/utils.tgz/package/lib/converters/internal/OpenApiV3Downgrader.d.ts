import { OpenApi, OpenApiV3 } from "@typia/interface";
export declare namespace OpenApiV3Downgrader {
    interface IComponentsCollection {
        original: OpenApi.IComponents;
        downgraded: OpenApiV3.IComponents;
    }
    const downgrade: (input: OpenApi.IDocument) => OpenApiV3.IDocument;
    const downgradeComponents: (input: OpenApi.IComponents) => IComponentsCollection;
    const downgradeSchema: (collection: IComponentsCollection) => (input: OpenApi.IJsonSchema) => OpenApiV3.IJsonSchema;
}
