import { OpenApi } from "@typia/interface";
export declare namespace LlmDescriptionInverter {
    const numeric: (description: string | undefined) => Pick<OpenApi.IJsonSchema.INumber, "minimum" | "maximum" | "exclusiveMinimum" | "exclusiveMaximum" | "multipleOf" | "description">;
    const string: (description: string | undefined) => Pick<OpenApi.IJsonSchema.IString, "format" | "pattern" | "contentMediaType" | "minLength" | "maxLength" | "description">;
    const array: (description: string | undefined) => Pick<OpenApi.IJsonSchema.IArray, "minItems" | "maxItems" | "uniqueItems" | "description">;
}
