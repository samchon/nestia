import { OpenApi, OpenApiV3_1 } from "@typia/interface";
export declare namespace OpenApiV3_1Upgrader {
    const convert: (input: OpenApiV3_1.IDocument) => OpenApi.IDocument;
    const convertComponents: (input: OpenApiV3_1.IComponents) => OpenApi.IComponents;
    const convertSchema: (components: OpenApiV3_1.IComponents) => (input: OpenApiV3_1.IJsonSchema) => OpenApi.IJsonSchema;
}
