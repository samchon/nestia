import { OpenApi, OpenApiV3_1 } from "@typia/interface";
export declare namespace OpenApiV3_1Downgrader {
    interface IComponentsCollection {
        original: OpenApi.IComponents;
        downgraded: OpenApiV3_1.IComponents;
    }
    const downgrade: (input: OpenApi.IDocument) => OpenApiV3_1.IDocument;
    const downgradeComponents: (input: OpenApi.IComponents) => IComponentsCollection;
    const downgradeSchema: (collection: IComponentsCollection) => (input: OpenApi.IJsonSchema) => OpenApiV3_1.IJsonSchema;
}
