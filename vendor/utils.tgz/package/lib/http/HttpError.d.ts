/**
 * Error thrown when HTTP request fails with non-2xx status.
 *
 * `HttpError` is thrown by {@link HttpLlm.execute} and
 * {@link HttpMigration.execute} when the server returns a non-2xx status code.
 * Contains the full HTTP context: method, path, status, headers, and response
 * body.
 *
 * The response body is available via {@link message} (raw string) or
 * {@link toJSON} (parsed JSON). For non-throwing behavior, use
 * {@link HttpLlm.propagate} or {@link HttpMigration.propagate} instead.
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare class HttpError extends Error {
    /** HTTP method used for the request. */
    readonly method: "GET" | "QUERY" | "DELETE" | "POST" | "PUT" | "PATCH" | "HEAD";
    /** Request path or URL. */
    readonly path: string;
    /** HTTP status code from server. */
    readonly status: number;
    /** Response headers from server. */
    readonly headers: Record<string, string | string[]>;
    /**
     * @param method HTTP method
     * @param path Request path or URL
     * @param status HTTP status code
     * @param headers Response headers
     * @param message Error message (response body)
     */
    constructor(method: "GET" | "QUERY" | "DELETE" | "POST" | "PUT" | "PATCH" | "HEAD", path: string, status: number, headers: Record<string, string | string[]>, message: string);
    /**
     * Serialize to JSON-compatible object.
     *
     * Lazily parses JSON message body on first call. If parsing fails, returns
     * the original string.
     *
     * @template T Expected response body type
     * @returns Structured HTTP error information
     */
    toJSON<T>(): HttpError.IProps<T>;
}
export declare namespace HttpError {
    /**
     * JSON representation of HttpError.
     *
     * @template T Response body type
     */
    interface IProps<T> {
        /** HTTP method. */
        method: "GET" | "QUERY" | "DELETE" | "POST" | "PUT" | "PATCH" | "HEAD";
        /** Request path or URL. */
        path: string;
        /** HTTP status code. */
        status: number;
        /** Response headers. */
        headers: Record<string, string | string[]>;
        /** Response body (parsed JSON or original string). */
        message: T;
    }
}
