import { IHttpMigrateApplication, OpenApi } from "@typia/interface";
export declare namespace HttpMigrateApplicationComposer {
    const compose: (document: OpenApi.IDocument) => IHttpMigrateApplication;
}
