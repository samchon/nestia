import { IHttpResponse } from "@typia/interface";
import type { HttpMigration } from "../HttpMigration";
export declare namespace HttpMigrateRouteFetcher {
    const execute: (props: HttpMigration.IFetchProps) => Promise<unknown>;
    const propagate: (props: HttpMigration.IFetchProps) => Promise<IHttpResponse>;
}
