import { IHttpResponse } from "@typia/interface";
import type { HttpLlm } from "../HttpLlm";
export declare namespace HttpLlmFunctionFetcher {
    const execute: (props: HttpLlm.IFetchProps) => Promise<unknown>;
    const propagate: (props: HttpLlm.IFetchProps) => Promise<IHttpResponse>;
}
