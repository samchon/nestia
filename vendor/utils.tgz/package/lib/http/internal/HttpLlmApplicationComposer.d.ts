import { IHttpLlmApplication, IHttpMigrateApplication } from "@typia/interface";
/**
 * Composes {@link IHttpLlmApplication} from an {@link IHttpMigrateApplication}.
 *
 * Converts OpenAPI-migrated HTTP routes into LLM function calling schemas,
 * filtering out unsupported methods (HEAD) and content types
 * (multipart/form-data), and shortening function names to fit the configured
 * maximum length.
 */
export declare namespace HttpLlmApplicationComposer {
    /**
     * Builds an {@link IHttpLlmApplication} from migrated HTTP routes.
     *
     * Iterates all routes, converts each to an {@link IHttpLlmFunction}, and
     * collects conversion errors. Applies function name shortening at the end.
     */
    const application: (props: {
        migrate: IHttpMigrateApplication;
        config?: Partial<IHttpLlmApplication.IConfig>;
    }) => IHttpLlmApplication;
    /**
     * Shortens function names exceeding the character limit.
     *
     * Tries progressively shorter accessor suffixes first, then falls back to
     * index-prefixed names, and finally UUID as a last resort.
     */
    const shorten: (app: IHttpLlmApplication, limit?: number) => void;
}
