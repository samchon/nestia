import { IHttpMigrateRoute, OpenApi } from "@typia/interface";
export declare namespace HttpMigrateRouteComposer {
    interface IProps {
        document: OpenApi.IDocument;
        method: "head" | "get" | "post" | "put" | "patch" | "delete" | "query";
        path: string;
        emendedPath: string;
        operation: OpenApi.IOperation;
    }
    const compose: (props: IProps) => IHttpMigrateRoute | string[];
}
