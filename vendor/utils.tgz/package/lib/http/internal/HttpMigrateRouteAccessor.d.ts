import { IHttpMigrateRoute } from "@typia/interface";
export declare namespace HttpMigrateRouteAccessor {
    const overwrite: (routes: IHttpMigrateRoute[]) => void;
}
