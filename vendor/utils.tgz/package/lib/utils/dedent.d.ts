/**
 * Remove common leading whitespace from template literal.
 *
 * Strips leading/trailing blank lines and removes the minimum indentation level
 * from all lines.
 *
 * @author Jeongho Nam - https://github.com/samchon
 * @param strings Template literal strings
 * @param values Interpolated values
 * @returns Dedented string
 */
export declare function dedent(strings: TemplateStringsArray, ...values: Array<boolean | number | string>): string;
