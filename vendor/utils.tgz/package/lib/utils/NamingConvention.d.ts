/**
 * String naming convention converters.
 *
 * `NamingConvention` converts between common code naming conventions:
 * camelCase, PascalCase, and snake_case. Handles edge cases like consecutive
 * uppercase letters (e.g., `XMLParser` → `xml_parser`) and leading
 * underscores.
 *
 * Functions:
 *
 * - {@link camel}: Convert to camelCase (`fooBar`)
 * - {@link pascal}: Convert to PascalCase (`FooBar`)
 * - {@link snake}: Convert to snake_case (`foo_bar`)
 * - {@link variable}: Test if string is valid JavaScript variable name
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace NamingConvention {
    /**
     * Convert to camelCase.
     *
     * @param str Input string
     * @returns CamelCase string
     */
    function camel(str: string): string;
    /**
     * Convert to PascalCase.
     *
     * @param str Input string
     * @returns PascalCase string
     */
    function pascal(str: string): string;
    /**
     * Convert to snake_case.
     *
     * @param str Input string
     * @returns Snake_case string
     */
    function snake(str: string): string;
    /**
     * Capitalize first character.
     *
     * @param str Input string
     * @returns Capitalized string
     */
    const capitalize: (str: string) => string;
    /**
     * Lowercase first character.
     *
     * @param str Input string
     * @returns Localized string
     */
    const localize: (str: string) => string;
    /**
     * Check if string is valid JavaScript variable name.
     *
     * @param str String to check
     * @returns True if valid variable name
     */
    const variable: (str: string) => boolean;
    /**
     * Check if string is JavaScript reserved word.
     *
     * @param str String to check
     * @returns True if reserved word
     */
    const reserved: (str: string) => boolean;
}
