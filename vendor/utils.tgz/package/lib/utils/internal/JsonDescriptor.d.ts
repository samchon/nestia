import { OpenApi } from "@typia/interface";
export declare namespace JsonDescriptor {
    const cascade: (props: {
        prefix: string;
        components: OpenApi.IComponents;
        schema: OpenApi.IJsonSchema.IReference;
        escape: boolean;
    }) => string | undefined;
    const take: (o: OpenApi.IJsonSchema.IObject) => string | undefined;
}
