import { IValidation } from "@typia/interface";
export declare function stringifyValidationFailure(failure: IValidation.IFailure): string;
