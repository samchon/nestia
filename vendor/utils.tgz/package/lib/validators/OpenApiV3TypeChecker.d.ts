import { OpenApiV3 } from "@typia/interface";
/**
 * Type checker for raw OpenAPI v3.0 JSON schemas.
 *
 * `OpenApiV3TypeChecker` provides type guard functions for
 * {@link OpenApiV3.IJsonSchema} (raw, unemended format). For typia's normalized
 * format, use {@link OpenApiTypeChecker} instead.
 *
 * Key differences from v3.1: v3.0 uses `nullable: true` property instead of
 * union types, and has no `const` or tuple support.
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace OpenApiV3TypeChecker {
    const isBoolean: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IBoolean;
    const isInteger: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IInteger;
    const isNumber: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.INumber;
    const isString: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IString;
    const isArray: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IArray;
    const isObject: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IObject;
    const isReference: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IReference;
    const isAllOf: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IAllOf;
    const isAnyOf: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IAnyOf;
    const isOneOf: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.IOneOf;
    const isNullOnly: (schema: OpenApiV3.IJsonSchema) => schema is OpenApiV3.IJsonSchema.INullOnly;
}
