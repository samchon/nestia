import { SwaggerV2 } from "@typia/interface";
/**
 * Type checker for Swagger v2.0 (OpenAPI v2) JSON schemas.
 *
 * `SwaggerV2TypeChecker` provides type guard functions for
 * {@link SwaggerV2.IJsonSchema}. For typia's normalized format, use
 * {@link OpenApiTypeChecker} instead.
 *
 * Key limitations vs OpenAPI v3.x: No `oneOf`/`anyOf`, no `nullable`, uses
 * `definitions` instead of `components.schemas`, body parameters use `in:
 * "body"` with `schema` property.
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace SwaggerV2TypeChecker {
    const isBoolean: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IBoolean;
    const isInteger: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IInteger;
    const isNumber: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.INumber;
    const isString: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IString;
    const isArray: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IArray;
    const isObject: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IObject;
    const isReference: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IReference;
    const isAllOf: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IAllOf;
    const isOneOf: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IOneOf;
    const isAnyOf: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.IAnyOf;
    const isNullOnly: (schema: SwaggerV2.IJsonSchema) => schema is SwaggerV2.IJsonSchema.INullOnly;
}
