import { OpenApi } from "@typia/interface";
import { IOpenApiValidatorContext } from "./IOpenApiValidatorContext";
export declare namespace OpenApiOneOfValidator {
    const validate: (ctx: IOpenApiValidatorContext<OpenApi.IJsonSchema.IOneOf>) => boolean;
}
