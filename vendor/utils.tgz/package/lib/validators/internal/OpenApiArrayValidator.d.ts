import { OpenApi } from "@typia/interface";
import { IOpenApiValidatorContext } from "./IOpenApiValidatorContext";
export declare namespace OpenApiArrayValidator {
    const validate: (ctx: IOpenApiValidatorContext<OpenApi.IJsonSchema.IArray>) => boolean;
}
