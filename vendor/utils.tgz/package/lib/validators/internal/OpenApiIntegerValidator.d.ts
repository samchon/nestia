import { OpenApi } from "@typia/interface";
import { IOpenApiValidatorContext } from "./IOpenApiValidatorContext";
export declare namespace OpenApiIntegerValidator {
    const validate: (ctx: IOpenApiValidatorContext<OpenApi.IJsonSchema.IInteger>) => boolean;
}
