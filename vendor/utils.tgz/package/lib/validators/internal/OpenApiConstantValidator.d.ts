import { OpenApi } from "@typia/interface";
import { IOpenApiValidatorContext } from "./IOpenApiValidatorContext";
export declare namespace OpenApiConstantValidator {
    const validate: (ctx: IOpenApiValidatorContext<OpenApi.IJsonSchema.IConstant>) => boolean;
}
