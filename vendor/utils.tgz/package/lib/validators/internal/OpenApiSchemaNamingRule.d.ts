import { OpenApi } from "@typia/interface";
export declare namespace OpenApiSchemaNamingRule {
    const getName: (schema: OpenApi.IJsonSchema, union?: boolean) => string;
}
