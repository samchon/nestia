import { OpenApi } from "@typia/interface";
import { IOpenApiValidatorContext } from "./IOpenApiValidatorContext";
export declare namespace OpenApiNumberValidator {
    const validate: (ctx: IOpenApiValidatorContext<OpenApi.IJsonSchema.INumber>) => boolean;
}
