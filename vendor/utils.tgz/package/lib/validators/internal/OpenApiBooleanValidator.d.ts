import { OpenApi } from "@typia/interface";
import { IOpenApiValidatorContext } from "./IOpenApiValidatorContext";
export declare namespace OpenApiBooleanValidator {
    const validate: (ctx: IOpenApiValidatorContext<OpenApi.IJsonSchema.IBoolean>) => boolean;
}
