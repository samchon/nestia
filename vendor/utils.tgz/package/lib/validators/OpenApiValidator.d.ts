import { IValidation, OpenApi } from "@typia/interface";
/**
 * OpenAPI JSON Schema validator.
 *
 * `OpenApiValidator` validates runtime data against {@link OpenApi.IJsonSchema}
 * definitions. Returns {@link IValidation} with detailed error paths and
 * expected types.
 *
 * Primary use case: Validating LLM-generated function call arguments. LLMs
 * frequently make type errors (e.g., `"123"` instead of `123`). Use the
 * validation errors to provide feedback and retry.
 *
 * Functions:
 *
 * - {@link create}: Create reusable validator function from schema
 * - {@link validate}: One-shot validation with inline schema
 *
 * Set `equals: true` to reject objects with extra properties (strict mode).
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace OpenApiValidator {
    const create: (props: {
        components: OpenApi.IComponents;
        schema: OpenApi.IJsonSchema;
        required: boolean;
        equals?: boolean;
    }) => (value: unknown) => IValidation<unknown>;
    const validate: (props: {
        components: OpenApi.IComponents;
        schema: OpenApi.IJsonSchema;
        value: unknown;
        required: boolean;
        equals?: boolean;
    }) => IValidation<unknown>;
}
