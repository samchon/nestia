import { OpenApiV3_1 } from "@typia/interface";
/**
 * Type checker for raw OpenAPI v3.1 JSON schemas.
 *
 * `OpenApiV3_1TypeChecker` provides type guard functions for
 * {@link OpenApiV3_1.IJsonSchema} (raw, unemended format). For typia's
 * normalized format, use {@link OpenApiTypeChecker} instead.
 *
 * Key v3.1 features: `const` keyword, `type` arrays (`["string", "null"]`),
 * `prefixItems` for tuples, JSON Schema draft 2020-12 compatibility.
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace OpenApiV3_1TypeChecker {
    const isConstant: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IConstant;
    const isBoolean: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IBoolean;
    const isInteger: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IInteger;
    const isNumber: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.INumber;
    const isString: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IString;
    const isArray: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IArray;
    const isObject: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IObject;
    const isReference: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IReference;
    const isRecursiveReference: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IRecursiveReference;
    const isAllOf: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IAllOf;
    const isAnyOf: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IAnyOf;
    const isOneOf: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IOneOf;
    const isNullOnly: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.INull;
    const isMixed: (schema: OpenApiV3_1.IJsonSchema) => schema is OpenApiV3_1.IJsonSchema.IMixed;
}
