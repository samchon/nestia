import unplugin from "./core/index";
declare const farm: typeof unplugin.farm;
export default farm;
