import unplugin from "./core/index";
declare const rspack: typeof unplugin.rspack;
export default rspack;
