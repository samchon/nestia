import type { UnpluginInstance } from "unplugin";
import type { TtscUnpluginOptions } from "./options";
import { resolveOptions } from "./options";
import { createTtscTransformCache, transformTtsc } from "./transform";
declare const unplugin: UnpluginInstance<TtscUnpluginOptions | undefined, false>;
export type { TtscUnpluginCompilerOptionsJson, TtscUnpluginOptions, } from "./options";
export { createTtscTransformCache, resolveOptions, transformTtsc, unplugin };
export default unplugin;
