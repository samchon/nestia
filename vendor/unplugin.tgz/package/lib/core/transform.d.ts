import type { ITtscCompilerTransformation } from "ttsc";
import type { TransformResult } from "unplugin";
import type { ResolvedTtscUnpluginOptions } from "./options";
export type TtscTransformResult = Exclude<TransformResult, string | null | undefined>;
export interface TtscTransformAlias {
    find: string;
    replacement: string;
}
export interface TtscCachedProjectTransform {
    inputHashes: Record<string, string>;
    projectRoot: string;
    result: ITtscCompilerTransformation;
}
export type TtscTransformCache = Map<string, Promise<TtscCachedProjectTransform>>;
export declare function createTtscTransformCache(): TtscTransformCache;
export declare function transformTtsc(id: string, source: string, options: ResolvedTtscUnpluginOptions, aliases?: unknown, cache?: TtscTransformCache): Promise<TtscTransformResult | undefined>;
export declare function stripQuery(id: string): string;
export declare function isDeclarationFile(id: string): boolean;
export declare function createTransformResult(source: string, code: string): TtscTransformResult | undefined;
