import unplugin from "./core/index";
declare const webpack: typeof unplugin.webpack;
export default webpack;
