import unplugin from "./core/index";
declare const esbuild: typeof unplugin.esbuild;
export default esbuild;
