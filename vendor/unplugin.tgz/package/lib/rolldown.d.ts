import unplugin from "./core/index";
declare const rolldown: typeof unplugin.rolldown;
export default rolldown;
