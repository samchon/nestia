import type { TtscUnpluginOptions } from "./core/options";
export interface BunLikePlugin {
    name: string;
    setup(build: BunLikeBuild): void | Promise<void>;
}
export interface BunLikeBuild {
    onLoad(options: {
        filter: RegExp;
    }, loader: (args: {
        path: string;
    }) => Promise<{
        contents: string;
    }>): void;
}
export default function bun(options?: TtscUnpluginOptions): BunLikePlugin;
