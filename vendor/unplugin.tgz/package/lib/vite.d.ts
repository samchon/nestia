import unplugin from "./core/index";
declare const vite: typeof unplugin.vite;
export default vite;
