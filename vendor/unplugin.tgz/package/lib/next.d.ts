import type { TtscUnpluginOptions } from "./core/options";
export type NextLikeConfig = Record<string, unknown> & {
    webpack?: (config: WebpackLikeConfig, options: unknown) => WebpackLikeConfig;
};
export type WebpackLikeConfig = Record<string, unknown> & {
    plugins?: unknown[];
};
export default function next(nextConfig?: NextLikeConfig, options?: TtscUnpluginOptions): NextLikeConfig;
