import unplugin from "./core/index";
declare const rollup: typeof unplugin.rollup;
export default rollup;
