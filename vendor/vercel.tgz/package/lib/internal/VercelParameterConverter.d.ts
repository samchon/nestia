import { ILlmSchema } from "@typia/interface";
import { Schema } from "ai";
export declare namespace VercelParameterConverter {
    const convert: (parameters: ILlmSchema.IParameters) => Schema<object>;
}
