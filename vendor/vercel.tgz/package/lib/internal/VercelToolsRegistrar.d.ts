import { IHttpLlmController, ILlmController } from "@typia/interface";
import { Tool } from "ai";
export declare namespace VercelToolsRegistrar {
    /**
     * Convert typia controllers to Vercel AI SDK tools.
     *
     * @param props Conversion properties
     * @returns Record of Vercel AI SDK Tools
     */
    const convert: (props: {
        controllers: Array<ILlmController | IHttpLlmController>;
        prefix?: boolean | undefined;
    }) => Record<string, Tool>;
}
