module github.com/microsoft/typescript-go/shim/tsoptions

go 1.26

require github.com/microsoft/typescript-go v0.0.0-20260429010842-56ab4af42157
