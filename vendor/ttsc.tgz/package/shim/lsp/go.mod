module github.com/microsoft/typescript-go/shim/lsp

go 1.26

require github.com/microsoft/typescript-go v0.0.0-20260429010842-56ab4af42157

require (
	github.com/Microsoft/go-winio v0.6.2 // indirect
	github.com/go-json-experiment/json v0.0.0-20260214004413-d219187c3433 // indirect
	github.com/klauspost/cpuid/v2 v2.2.10 // indirect
	github.com/mackerelio/go-osstat v0.2.7 // indirect
	github.com/zeebo/xxh3 v1.1.0 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.43.0 // indirect
	golang.org/x/text v0.36.0 // indirect
)
