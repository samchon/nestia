/** One contributor's resolved Go source plus its target sub-package name. */
export interface ITtscBuildContributor {
    /** Sub-package suffix: scratch lands at `<host>/contrib/<name>/`. */
    name: string;
    /** Absolute path to the contributor's source directory. */
    source: string;
}
/** Build one Go source plugin into a cached executable. */
export declare function buildSourcePlugin(opts: {
    source: string;
    pluginName: string;
    baseDir: string;
    cacheDir?: string;
    contributors?: readonly ITtscBuildContributor[];
    label?: string;
    overlayDirs?: readonly string[];
    quiet?: boolean;
    ttscVersion: string;
    tsgoVersion: string;
}): string;
export declare function resolvePluginCacheRoot(projectRoot: string, cacheDir?: string): string;
export declare function resolveGlobalPluginCacheRoot(): string;
export declare function defaultPluginCacheCleanTargets(projectRoot: string): string[];
export declare function computeCacheKey(inputs: {
    contributors?: readonly ITtscBuildContributor[];
    dir: string;
    entry: string;
    goBinary?: string;
    overlayDirs?: readonly string[];
    ttscVersion: string;
    tsgoVersion: string;
}): string;
