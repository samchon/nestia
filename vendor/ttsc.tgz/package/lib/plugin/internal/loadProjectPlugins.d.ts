import type { ITtscProjectPluginConfig } from "../../structures/ITtscProjectPluginConfig";
import type { ITtscLoadedNativePlugin } from "../../structures/internal/ITtscLoadedNativePlugin";
import type { ITtscParsedProjectConfig } from "../../structures/internal/ITtscParsedProjectConfig";
export declare function loadProjectPlugins(options: {
    binary: string;
    cacheDir?: string;
    cwd?: string;
    entries?: readonly ITtscProjectPluginConfig[] | false;
    file?: string;
    projectRoot?: string;
    tsconfig?: string;
}): {
    nativePlugins: ITtscLoadedNativePlugin[];
    project: ITtscParsedProjectConfig;
};
export declare function hasProjectPluginEntries(project: ITtscParsedProjectConfig, entries?: readonly ITtscProjectPluginConfig[] | false): boolean;
