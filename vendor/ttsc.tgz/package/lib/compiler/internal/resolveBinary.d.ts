/** Resolve the ttsc helper binary path, or null when unavailable. */
export declare function resolveBinary(opts?: {
    env?: NodeJS.ProcessEnv;
}): string | null;
