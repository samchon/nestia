/** Resolve the consumer project's TypeScript-Go preview binary. */
export declare function resolveTsgo(opts?: {
    binary?: string;
    cwd?: string;
    env?: NodeJS.ProcessEnv;
    resolveFrom?: string;
}): {
    binary: string;
    packageJson: string;
    packageRoot: string;
    version: string;
    gitHead?: undefined;
    platformPackageJson?: undefined;
} | {
    binary: string;
    gitHead: string | undefined;
    packageJson: string;
    packageRoot: string;
    platformPackageJson: string;
    version: string;
};
