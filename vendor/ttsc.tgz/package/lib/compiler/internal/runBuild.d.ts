import type { ITtscCompilerDiagnostic } from "../../structures/ITtscCompilerDiagnostic";
import type { TtscBuildOptions } from "../../structures/internal/TtscBuildOptions";
import type { TtscBuildResult } from "../../structures/internal/TtscBuildResult";
/**
 * Run `ttsc` against a tsconfig. Returns once the binary exits so the CLI can
 * decide how to surface diagnostics. Does not throw on non-zero exit.
 */
export declare function runBuild(options?: TtscBuildOptions & {
    skipDiagnosticsCheck?: boolean;
    forceListEmittedFiles?: boolean;
}): TtscBuildResult;
export declare function appendBuildOutput(left: TtscBuildResult, right: TtscBuildResult): TtscBuildResult;
type PartialBuildResult = Omit<TtscBuildResult, "diagnostics"> & {
    diagnostics?: ITtscCompilerDiagnostic[];
};
export declare function normalizeBuildOutput(result: PartialBuildResult, cwd?: string): TtscBuildResult;
export {};
