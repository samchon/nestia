import type { ITtscCompilerContext } from "../../structures/ITtscCompilerContext";
import type { TtscBuildResult } from "../../structures/internal/TtscBuildResult";
/** Transform a project and capture TypeScript source output in memory. */
export declare function transformProjectInMemory(options: ITtscCompilerContext): {
    result: TtscBuildResult;
    typescript: Record<string, string>;
};
