import type { ITtscLoadedNativePlugin } from "../../structures/internal/ITtscLoadedNativePlugin";
/**
 * Reports whether the given transform source is linked into another compiler
 * host instead of owning the process itself.
 */
export declare function isLinkedTransform(plugin: ITtscLoadedNativePlugin): boolean;
/**
 * Verifies that all transform plugins in `plugins` either resolve to the same
 * native binary (the common case) after linked sources are removed from the
 * compiler-owner set.
 *
 * Two callers exist with subtly different error wording: the build path
 * (`runBuild.ts`) reports "multiple compiler native backends cannot share one
 * emit pass" while the source-to-source path (`transformProjectInMemory.ts`)
 * reports "cannot share one source-to-source pass". The `pass` argument selects
 * the appropriate phrase so the error message remains diagnostic-grade instead
 * of generic.
 */
export declare function assertSharedHostCompatibility(plugins: readonly ITtscLoadedNativePlugin[], pass: "emit" | "source-to-source"): void;
/**
 * Picks the native binary that must own the compiler pass. Linked transform
 * sources ride inside a host that uses driver.LoadProgram, so an executable
 * transform wins when one is present.
 */
export declare function selectSharedHostPlugin(plugins: readonly ITtscLoadedNativePlugin[]): ITtscLoadedNativePlugin;
export declare function linkedTransformPlugins(plugins: readonly ITtscLoadedNativePlugin[]): ITtscLoadedNativePlugin[];
