import type { TtscSingleFileEmitOptions } from "../../structures/internal/TtscSingleFileEmitOptions";
/** Emit one source file by building its project into a temporary directory. */
export declare function runSingleFileEmit(options: TtscSingleFileEmitOptions): string;
