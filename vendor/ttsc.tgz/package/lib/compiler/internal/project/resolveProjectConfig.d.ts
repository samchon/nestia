import type { ITtscProjectLocatorOptions } from "../../../structures/internal/ITtscProjectLocatorOptions";
/** Resolve the tsconfig/jsconfig that owns a ttsc invocation. */
export declare function resolveProjectConfig(opts?: ITtscProjectLocatorOptions): string;
