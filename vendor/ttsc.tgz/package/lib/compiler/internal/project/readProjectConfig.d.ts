import type { ITtscParsedProjectConfig } from "../../../structures/internal/ITtscParsedProjectConfig";
import type { ITtscProjectLocatorOptions } from "../../../structures/internal/ITtscProjectLocatorOptions";
/** Read the resolved project config subset used by ttsc. */
export declare function readProjectConfig(opts?: ITtscProjectLocatorOptions): ITtscParsedProjectConfig;
