/** Locate the JavaScript file emitted for a TypeScript source file. */
export declare function resolveEmittedJavaScript(options: {
    emittedFiles?: readonly string[];
    outDir: string;
    projectRoot: string;
    sourceFile: string;
}): string | null;
