/** Build the native ttsc compiler host used by in-memory API compilation. */
export declare function buildNativeCompiler(options: {
    cacheBaseDir: string;
    cacheDir?: string;
    packageRoot: string;
}): string;
