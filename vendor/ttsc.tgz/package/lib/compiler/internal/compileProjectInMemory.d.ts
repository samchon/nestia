import type { ITtscCompilerContext } from "../../structures/ITtscCompilerContext";
import type { TtscBuildResult } from "../../structures/internal/TtscBuildResult";
/**
 * Compile a project and capture emitted files without writing to the project
 * tree.
 */
export declare function compileProjectInMemory(options: ITtscCompilerContext): {
    output: Record<string, string>;
    result: TtscBuildResult;
};
