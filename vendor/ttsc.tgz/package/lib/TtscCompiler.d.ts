import type { ITtscCompilerContext } from "./structures/ITtscCompilerContext";
import type { ITtscCompilerResult } from "./structures/ITtscCompilerResult";
import type { ITtscCompilerTransformation } from "./structures/ITtscCompilerTransformation";
/**
 * Programmatic compiler host for the `ttsc` TypeScript-Go pipeline.
 *
 * `TtscCompiler` is the root JavaScript API exported by the `ttsc` package. It
 * represents one resolved project context: a working directory, an optional
 * project config path, an optional native toolchain override, an environment, a
 * cache root, and a plugin list. Those values are captured by the constructor
 * and are intentionally not replaceable per method call.
 *
 * The class exposes only the operations that make sense for an embedded
 * compiler host:
 *
 * - {@link TtscCompiler.prepare}: build configured Go source plugins into the
 *   cache before a later compile.
 * - {@link TtscCompiler.clean}: remove the cache owned by this compiler context.
 * - {@link TtscCompiler.compile}: compile the configured project and return a
 *   structured result instead of terminal text.
 * - {@link TtscCompiler.transform}: transform the configured project and return an
 *   embed-style transformation result.
 */
export declare class TtscCompiler {
    private readonly context;
    constructor(context?: ITtscCompilerContext);
    /**
     * Build every configured source plugin into the instance cache.
     *
     * This method loads the project plugin descriptors, resolves their
     * {@link ITtscPlugin.source} paths, and compiles those Go command packages
     * into the ttsc cache. It is useful when a host application wants to pay the
     * lazy build cost before the first compile call.
     *
     * `prepare()` is not a project check. It does not create a TypeScript-Go
     * Program, does not run diagnostics, and does not emit output files.
     *
     * @returns Compiled native plugin binary paths.
     */
    prepare(): string[];
    /**
     * Remove compiled cache artifacts for this compiler instance.
     *
     * When the constructor received `cacheDir`, this method removes exactly that
     * directory. When `TTSC_CACHE_DIR` is active, it removes that override's
     * plugin cache plus legacy project-local caches. Otherwise it removes the
     * default global plugin cache plus legacy project-local caches.
     *
     * The cache target comes from the constructor context. Create another
     * `TtscCompiler` instance to clean another project or another cache root.
     *
     * @returns Cache directories that were removed.
     */
    clean(): string[];
    /**
     * Compile the configured project.
     *
     * The public API does not write emitted files into the caller's project tree.
     * For projects without plugins, ttsc uses its native TypeScript-Go host's
     * `WriteFile` callback to capture output in memory. For projects with native
     * plugins, ttsc runs the plugin pipeline against a temporary output
     * directory, reads the generated text artifacts, and removes the temporary
     * directory before returning.
     *
     * The result uses an `embed-typescript`-style discriminated union: `success`
     * for clean compiles, `failure` for normal compiler diagnostics, and
     * `exception` for host setup or process failures.
     *
     * @returns Structured compilation result containing diagnostics or output.
     */
    compile(): ITtscCompilerResult;
    /**
     * Transform the configured project and return TypeScript text by file path.
     *
     * This is the source-to-source API for plugin authors. It must not return
     * JavaScript emit, declaration files, or source maps; those artifacts belong
     * to {@link TtscCompiler.compile}. A transform sidecar is expected to write
     * JSON shaped as `{ "typescript": { "src/file.ts": "..." } }` to stdout. When
     * no transform sidecar is configured, ttsc returns the TypeScript files
     * loaded by the TypeScript-Go Program together with normal diagnostics.
     *
     * The returned shape mirrors `embed-typescript`'s transformation API:
     * `success` and `failure` carry a `typescript` map, while unexpected host
     * errors return `exception`.
     *
     * @returns Transformation result containing TypeScript text or diagnostics.
     */
    transform(): ITtscCompilerTransformation;
    private compilerContext;
    private resolveProjectExecution;
    private resolveCleanProjectRoot;
    private resolveCwd;
    private resolveCacheDir;
    private resolvePluginCacheDir;
}
