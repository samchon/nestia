export declare function runTtsx(argv?: readonly string[]): number;
