export declare function runTtsc(argv?: readonly string[]): number;
