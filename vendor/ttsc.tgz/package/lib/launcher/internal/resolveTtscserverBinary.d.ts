/**
 * Resolve the platform-specific ttscserver binary path. Looks first at the
 * TTSCSERVER_BINARY environment override (must be absolute), then at the
 * shipped per-platform npm package (`@ttsc/<platform>-<arch>/bin/ttscserver`),
 * then at the local-build fallback under `packages/native/`.
 *
 * Mirrors `resolveBinary` for the ttsc helper so editors that install ttsc via
 * pnpm see the LSP host alongside the existing helper.
 */
export declare function resolveTtscserverBinary(opts?: {
    env?: NodeJS.ProcessEnv;
}): string | null;
