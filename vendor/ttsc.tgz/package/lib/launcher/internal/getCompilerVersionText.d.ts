import type { TtscCommonOptions } from "../../structures/internal/TtscCommonOptions";
/** Format the CLI version banner from the wrapper package and resolved tsgo. */
export declare function getCompilerVersionText(options?: TtscCommonOptions): string;
