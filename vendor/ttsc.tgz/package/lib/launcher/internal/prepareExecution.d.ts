import type { TtscCommonOptions } from "../../structures/internal/TtscCommonOptions";
/** Build the owning project and locate the emitted JavaScript entry for `ttsx`. */
export declare function prepareExecution(entryFile: string, options?: TtscCommonOptions & {
    cacheDir?: string;
    project?: string;
}): {
    emitDir: string;
    entryFile: string;
    moduleKind: "cjs" | "esm";
};
