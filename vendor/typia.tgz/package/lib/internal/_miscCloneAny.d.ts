import { Resolved } from "@typia/interface";
export declare const _miscCloneAny: <T>(value: T) => Resolved<T>;
