import { IJsonParseResult, ILlmSchema } from "@typia/interface";
export declare const _parseLlmArguments: <T>(input: string, parameters: ILlmSchema.IParameters) => IJsonParseResult<T>;
