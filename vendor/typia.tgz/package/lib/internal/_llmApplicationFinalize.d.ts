import { ILlmApplication } from "@typia/interface";
export declare const _llmApplicationFinalize: <Class extends object = any>(app: ILlmApplication.__IPrimitive<Class>, config?: Partial<Pick<ILlmApplication.IConfig, "validate">>) => ILlmApplication<Class>;
