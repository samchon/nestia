import { OpenApi } from "@typia/interface";
export declare const _randomBigint: (props: OpenApi.IJsonSchema.IInteger) => bigint;
