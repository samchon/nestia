import { IReadableURLSearchParams } from "@typia/interface";
export declare const _httpQueryParseURLSearchParams: (input: string | IReadableURLSearchParams) => IReadableURLSearchParams;
