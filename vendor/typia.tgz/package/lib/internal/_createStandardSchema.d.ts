import { StandardSchemaV1 } from "@standard-schema/spec";
import { IValidation } from "@typia/interface";
export declare const _createStandardSchema: <T>(fn: (input: unknown) => IValidation<T>) => ((input: unknown) => IValidation<T>) & StandardSchemaV1<T, T>;
