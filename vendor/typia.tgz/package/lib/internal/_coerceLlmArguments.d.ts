import { ILlmSchema } from "@typia/interface";
export declare const _coerceLlmArguments: <T>(value: unknown, parameters: ILlmSchema.IParameters) => T;
