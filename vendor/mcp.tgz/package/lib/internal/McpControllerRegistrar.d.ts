import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { IHttpLlmController, ILlmController } from "@typia/interface";
export declare namespace McpControllerRegistrar {
    const register: (props: {
        server: McpServer | Server;
        controllers: Array<ILlmController | IHttpLlmController>;
        preserve?: boolean | undefined;
    }) => void;
}
