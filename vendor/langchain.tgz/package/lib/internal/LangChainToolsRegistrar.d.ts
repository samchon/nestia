import { DynamicStructuredTool } from "@langchain/core/tools";
import { IHttpLlmController, ILlmController } from "@typia/interface";
export declare namespace LangChainToolsRegistrar {
    const convert: (props: {
        controllers: Array<ILlmController | IHttpLlmController>;
        prefix?: boolean | undefined;
    }) => DynamicStructuredTool[];
}
