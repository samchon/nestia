/**
 * Atomic (primitive) type utilities for typia's type system.
 *
 * @author Jeongho Nam - https://github.com/samchon
 */
export declare namespace Atomic {
    /** Union of JavaScript primitive value types. */
    type Type = boolean | number | string | bigint;
    /** String literal names for atomic types. */
    type Literal = "boolean" | "integer" | "number" | "string" | "bigint";
    /** Maps literal type names to their corresponding value types. */
    type Mapper = {
        boolean: boolean;
        integer: number;
        number: number;
        string: string;
        bigint: bigint;
    };
}
